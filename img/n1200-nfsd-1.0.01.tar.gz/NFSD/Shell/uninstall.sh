#!/bin/sh

[ -t 1 ] && set -x
set -e
trap "echo fail" 0 1 2 3 15

mod_name='NFSD'

# setup temporary (volatile) storage for module upgrade
rm -rf /tmp/nfsd > /dev/null 2>&1 ; mkdir /tmp/nfsd 
cp /raid/module/cfg/nfsd.db /tmp/nfsd/nfsd.db
cp /raid/module/"$mod_name"/lib/exports /tmp/nfsd/exports

sqlite /raid/module/cfg/module.db "delete from module where name = '$mod_name'"
sqlite /raid/module/cfg/module.db "delete from mod where module = '$mod_name'"

/raid/module/cfg/module.rc/"$mod_name.rc" stop

rm -rf "/raid/module/cfg/module.rc/$mod_name.rc"
rm -rf "/raid/module/$mod_name"
rm -f "/img/htdocs/module/$mod_name"
rm -f /raid/module/cfg/nfsd.db
rm -f /etc/exports
rm -f /var/lib/nfs

trap '' 0 1 2 3 15

echo 'pass'
