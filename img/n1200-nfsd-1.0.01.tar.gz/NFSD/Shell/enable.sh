#!/bin/sh

[ -t 1 ] && set -x

mod_name=$1
mod_enable=$2

if [ "$mod_enable" = 'No' ];then
        [ -d "/img/htdocs/module/$mod_name" ] || ln -fs "/raid/module/$mod_name/www" "/img/htdocs/module/$mod_name"
        /raid/module/cfg/module.rc/"$mod_name.rc" start >/dev/null 2>&1
elif [ "$mod_enable" = 'Yes' ];then
	rm -f "/img/htdocs/module/$mod_name"
        /raid/module/cfg/module.rc/"$mod_name.rc" stop >/dev/null 2>&1
else
	echo 'fail'
	exit
fi

echo 'pass'
