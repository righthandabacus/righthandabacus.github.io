#!/bin/sh

[ -t 1 ] && set -x
set -e
trap "echo fail" 0 1 2 3 15

mod_name='NFSD'

[ -d /raid/module/cfg/module.rc ] || mkdir -p /raid/module/cfg/module.rc
[ -d /img/htdocs/module ] || mkdir /img/htdocs/module

for dir in shell lib www bin
do
	mkdir -p "/raid/module/$mod_name/$dir"
done

cp /tmp/module/Shell/module.rc /raid/module/cfg/module.rc/$mod_name.rc
cp -a /tmp/module/Shell/*         /raid/module/$mod_name/shell
cp -a /tmp/module/System/*        /raid/module/$mod_name/lib
cp -a /tmp/module/Binary/*	  /raid/module/$mod_name/bin
cp -a /tmp/module/WWW/*	          /raid/module/$mod_name/www
cp /tmp/module/Configure/license.txt /raid/module/$mod_name/COPY

# copy from temporary (volatile) storage on module upgrade
[ -s /tmp/nfsd/nfsd.db ] && cp /tmp/nfsd/nfsd.db /raid/module/cfg/nfsd.db
[ -s /tmp/nfsd/exports ] && cp /tmp/nfsd/exports /raid/module/"$mod_name"/lib/exports
touch /raid/module/$mod_name/lib/exports

rm -f /img/htdocs/module/$mod_name
ln -s /raid/module/$mod_name/www /img/htdocs/module/$mod_name

[ -s /raid/module/cfg/nfsd.db ] || sqlite /raid/module/cfg/nfsd.db "create table nfsd (id integer primary key, export varchar(255), subnet varchar(18), uid int)"

trap '' 0 1 2 3 15

echo pass
