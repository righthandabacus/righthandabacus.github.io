<?php
	if (!$db = sqlite_open('/raid/module/cfg/nfsd.db'))
		die("can't open nfsd.cfg database:");

	if ($_POST['nfsd_export'] && $_POST['nfsd_subnet']) {
		if (!sqlite_query($db, "INSERT INTO nfsd (export,subnet,uid) VALUES ('$_POST[nfsd_export]','$_POST[nfsd_subnet]','$_POST[nfsd_uid]')"))
			die("db error (insert): " . sqlite_error_string(sqlite_last_error()));
	}

	foreach ($_POST['nfsd_remove'] as $id) {
		if (!sqlite_query($db, "DELETE FROM nfsd WHERE id = $id"))
			die("db error (delete): " . sqlite_error_string(sqlite_last_error()));
	}

	if (!$fp = fopen("/etc/exports", "w"))
		die("can't open /etc/exports");

	$r = sqlite_query($db, "SELECT export,subnet,uid FROM nfsd");

	while ($a = sqlite_fetch_array($r, SQLITE_ASSOC)) {
		$gid = getGroups($a[uid]);

		if ($a[uid] == -1)
			fwrite($fp, "/raid$a[export]\t$a[subnet](rw,async,insecure,no_root_squash)\n");
		else
			fwrite($fp, "/raid$a[export]\t$a[subnet](rw,async,insecure,all_squash,anonuid=$a[uid],anongid=$gid)\n");
	}

	fclose($fp);

	shell_exec("/raid/module/NFSD/bin/exportfs -r");

	header("Location: /adm/getform.html?Module=NFSD");
?>

<?php

function getGroupsInit()
{
    global $_uidGid;
    
    if (!$fp = fopen("/etc/passwd", "r"))
        return false;
    
    while ($line = fgets($fp)) {
        $a = split(":", $line);
        if ($a[0] == "nobody")
            $_uidGid[$a[2]] = $a[3];
        if ($a[0] != "admin" && $a[2] > 1000)
            $_uidGid[$a[2]] = $a[3];
    }

    fclose($fp);
}

function getGroups($search = false)
{                                                                                                  
    global $_uidGid;
                                                                               
    if (!$_uidGid)
        getGroupsInit();

    if (!$search)
        return ($_uidGid);

    foreach ($_uidGid as $uid => $gid) {
        if ($search == $uid)
            return ($gid);
    }
}

?>
